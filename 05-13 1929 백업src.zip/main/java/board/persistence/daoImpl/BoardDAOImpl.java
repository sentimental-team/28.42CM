package board.persistence.daoImpl;

public class BoardDAOImpl {

}
