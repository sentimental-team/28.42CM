package board.persistence.dao;

public class BoardDAO {

}
