package board.service;

public class BoardService {

}
