package board.dto;

public class BoardDTO {

}
