package board.controller;

public class BoardController {

}
