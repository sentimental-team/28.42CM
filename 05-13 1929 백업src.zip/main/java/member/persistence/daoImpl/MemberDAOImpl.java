package member.persistence.daoImpl;

public class MemberDAOImpl {

}
