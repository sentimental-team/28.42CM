package member.persistence.dao;

public class MemberDAO {

}
